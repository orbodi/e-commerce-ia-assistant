import os
import io
from flask import Flask, render_template, request, redirect, url_for, flash, send_file
from extensions import db
from models import Enseignant, Salle, Groupe, Matiere, Creneau, GenerationLog, JOURS, CRENEAUX
from scheduler import generer_emploi_du_temps

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{os.path.join(BASE_DIR, 'ascencia.db')}"
app.config["SECRET_KEY"] = "dev-cle-a-changer-en-production"
db.init_app(app)


# ============================================================
# TABLEAU DE BORD
# ============================================================
@app.route("/")
def dashboard():
    stats = {
        "enseignants": Enseignant.query.count(),
        "salles": Salle.query.count(),
        "groupes": Groupe.query.count(),
        "matieres": Matiere.query.count(),
        "seances_total": sum(m.nb_seances for m in Matiere.query.all()),
    }
    dernier_log = GenerationLog.query.order_by(GenerationLog.date_generation.desc()).first()
    return render_template("dashboard.html", stats=stats, log=dernier_log)


# ============================================================
# ENSEIGNANTS
# ============================================================
@app.route("/enseignants", methods=["GET", "POST"])
def enseignants():
    if request.method == "POST":
        nom = request.form.get("nom", "").strip()
        dispo = []
        for j in range(len(JOURS)):
            for c in range(len(CRENEAUX)):
                if request.form.get(f"dispo_{j}_{c}"):
                    dispo.append([j, c])
        if nom:
            db.session.add(Enseignant(nom=nom, disponibilites=dispo))
            db.session.commit()
            flash(f"Enseignant « {nom} » ajouté.", "success")
        return redirect(url_for("enseignants"))

    liste = Enseignant.query.order_by(Enseignant.nom).all()
    return render_template("enseignants.html", enseignants=liste, jours=JOURS, creneaux=CRENEAUX)


@app.route("/enseignants/<int:id>/supprimer", methods=["POST"])
def supprimer_enseignant(id):
    e = Enseignant.query.get_or_404(id)
    db.session.delete(e)
    db.session.commit()
    flash(f"Enseignant « {e.nom} » supprimé.", "info")
    return redirect(url_for("enseignants"))


# ============================================================
# SALLES
# ============================================================
@app.route("/salles", methods=["GET", "POST"])
def salles():
    if request.method == "POST":
        nom = request.form.get("nom", "").strip()
        capacite = request.form.get("capacite", type=int)
        type_salle = request.form.get("type", "standard")
        if nom and capacite:
            db.session.add(Salle(nom=nom, capacite=capacite, type=type_salle))
            db.session.commit()
            flash(f"Salle « {nom} » ajoutée.", "success")
        return redirect(url_for("salles"))

    liste = Salle.query.order_by(Salle.nom).all()
    return render_template("salles.html", salles=liste)


@app.route("/salles/<int:id>/supprimer", methods=["POST"])
def supprimer_salle(id):
    s = Salle.query.get_or_404(id)
    db.session.delete(s)
    db.session.commit()
    flash(f"Salle « {s.nom} » supprimée.", "info")
    return redirect(url_for("salles"))


# ============================================================
# GROUPES
# ============================================================
@app.route("/groupes", methods=["GET", "POST"])
def groupes():
    if request.method == "POST":
        nom = request.form.get("nom", "").strip()
        effectif = request.form.get("effectif", type=int)
        if nom and effectif:
            db.session.add(Groupe(nom=nom, effectif=effectif))
            db.session.commit()
            flash(f"Groupe « {nom} » ajouté.", "success")
        return redirect(url_for("groupes"))

    liste = Groupe.query.order_by(Groupe.nom).all()
    return render_template("groupes.html", groupes=liste)


@app.route("/groupes/<int:id>/supprimer", methods=["POST"])
def supprimer_groupe(id):
    g = Groupe.query.get_or_404(id)
    db.session.delete(g)
    db.session.commit()
    flash(f"Groupe « {g.nom} » supprimé.", "info")
    return redirect(url_for("groupes"))


# ============================================================
# MATIERES
# ============================================================
@app.route("/matieres", methods=["GET", "POST"])
def matieres():
    if request.method == "POST":
        nom = request.form.get("nom", "").strip()
        nb_seances = request.form.get("nb_seances", type=int)
        enseignant_id = request.form.get("enseignant_id", type=int)
        groupe_id = request.form.get("groupe_id", type=int)
        if nom and nb_seances and enseignant_id and groupe_id:
            db.session.add(Matiere(nom=nom, nb_seances=nb_seances,
                                    enseignant_id=enseignant_id, groupe_id=groupe_id))
            db.session.commit()
            flash(f"Matière « {nom} » ajoutée.", "success")
        else:
            flash("Merci de renseigner tous les champs (enseignants/groupes doivent exister).", "danger")
        return redirect(url_for("matieres"))

    liste = Matiere.query.order_by(Matiere.nom).all()
    return render_template("matieres.html", matieres=liste,
                           enseignants=Enseignant.query.order_by(Enseignant.nom).all(),
                           groupes=Groupe.query.order_by(Groupe.nom).all())


@app.route("/matieres/<int:id>/supprimer", methods=["POST"])
def supprimer_matiere(id):
    m = Matiere.query.get_or_404(id)
    db.session.delete(m)
    db.session.commit()
    flash(f"Matière « {m.nom} » supprimée.", "info")
    return redirect(url_for("matieres"))


# ============================================================
# GENERATION
# ============================================================
@app.route("/generer", methods=["GET", "POST"])
def generer():
    resultat = None
    if request.method == "POST":
        resultat = generer_emploi_du_temps()
        if resultat.status == "OK":
            flash(f"Emploi du temps généré : {resultat.nb_seances} séances placées, "
                  f"{resultat.nb_heures_creuses} heure(s) creuse(s) restante(s), "
                  f"en {resultat.duree:.1f}s.", "success")
        else:
            flash(resultat.message or "La génération a échoué.", "danger")
    return render_template("generer.html", resultat=resultat)


# ============================================================
# CONSULTATION DE L'EMPLOI DU TEMPS
# ============================================================
@app.route("/emploi-du-temps")
def emploi_du_temps():
    vue = request.args.get("vue", "groupe")
    cible_id = request.args.get("id", type=int)

    groupes_l = Groupe.query.order_by(Groupe.nom).all()
    enseignants_l = Enseignant.query.order_by(Enseignant.nom).all()
    salles_l = Salle.query.order_by(Salle.nom).all()

    creneaux = Creneau.query.all()
    if vue == "groupe" and cible_id:
        creneaux = [c for c in creneaux if c.matiere.groupe_id == cible_id]
    elif vue == "enseignant" and cible_id:
        creneaux = [c for c in creneaux if c.matiere.enseignant_id == cible_id]
    elif vue == "salle" and cible_id:
        creneaux = [c for c in creneaux if c.salle_id == cible_id]

    # grille[jour_index][creneau_index] = liste de créneaux
    grille = {j: {c: [] for c in range(len(CRENEAUX))} for j in range(len(JOURS))}
    for c in creneaux:
        grille[c.jour_index][c.creneau_index].append(c)

    return render_template("emploi_du_temps.html", jours=JOURS, creneaux_labels=CRENEAUX,
                            grille=grille, vue=vue, cible_id=cible_id,
                            groupes=groupes_l, enseignants=enseignants_l, salles=salles_l)


# ============================================================
# EXPORT EXCEL
# ============================================================
@app.route("/export/excel")
def export_excel():
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment

    wb = Workbook()
    wb.remove(wb.active)

    groupes_l = Groupe.query.order_by(Groupe.nom).all()
    entete_fill = PatternFill(start_color="1B2A4A", end_color="1B2A4A", fill_type="solid")
    entete_font = Font(color="FFFFFF", bold=True)

    for groupe in groupes_l:
        ws = wb.create_sheet(title=groupe.nom[:31])
        ws.cell(row=1, column=1, value="Créneau")
        for j, jour in enumerate(JOURS):
            ws.cell(row=1, column=j + 2, value=jour)
        for col in range(1, len(JOURS) + 2):
            cell = ws.cell(row=1, column=col)
            cell.fill = entete_fill
            cell.font = entete_font
            cell.alignment = Alignment(horizontal="center")

        creneaux = Creneau.query.join(Matiere).filter(Matiere.groupe_id == groupe.id).all()
        for c_idx, label in enumerate(CRENEAUX):
            ws.cell(row=c_idx + 2, column=1, value=label).font = Font(bold=True)
            for c in creneaux:
                if c.creneau_index == c_idx:
                    texte = f"{c.matiere.nom}\n{c.matiere.enseignant.nom} — {c.salle.nom}"
                    cell = ws.cell(row=c_idx + 2, column=c.jour_index + 2, value=texte)
                    cell.alignment = Alignment(wrap_text=True, vertical="center")
        for col_letter in "ABCDEF":
            ws.column_dimensions[col_letter].width = 24

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(buf, as_attachment=True, download_name="emploi_du_temps.xlsx",
                      mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


with app.app_context():
    db.create_all()

if __name__ == "__main__":
    app.run(debug=True, port=5000, use_reloader=False)
