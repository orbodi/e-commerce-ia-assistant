"""Peuple la base avec un jeu de données de démonstration (à lancer une fois)."""
from app import app
from extensions import db
from models import Enseignant, Salle, Groupe, Matiere

SLOTS_TOUS = [[j, c] for j in range(5) for c in range(4)]
SLOTS_SAUF_MERCREDI = [[j, c] for j in range(5) for c in range(4) if j != 2]
SLOTS_SAUF_VENDREDI_APREM = [[j, c] for j in range(5) for c in range(4) if not (j == 4 and c >= 2)]

with app.app_context():
    db.drop_all()
    db.create_all()

    profA = Enseignant(nom="Prof. Amegan", disponibilites=SLOTS_TOUS)
    profB = Enseignant(nom="Prof. Bakoubé", disponibilites=SLOTS_SAUF_VENDREDI_APREM)
    profC = Enseignant(nom="Prof. Comlan", disponibilites=SLOTS_SAUF_MERCREDI)
    db.session.add_all([profA, profB, profC])
    db.session.commit()

    s101 = Salle(nom="Salle 101", capacite=40, type="standard")
    s102 = Salle(nom="Salle 102", capacite=30, type="standard")
    amphi = Salle(nom="Amphi A", capacite=100, type="amphi")
    db.session.add_all([s101, s102, amphi])
    db.session.commit()

    l3info = Groupe(nom="L3-Info", effectif=35)
    l3gestion = Groupe(nom="L3-Gestion", effectif=25)
    db.session.add_all([l3info, l3gestion])
    db.session.commit()

    db.session.add_all([
        Matiere(nom="Algorithmique", nb_seances=2, enseignant_id=profA.id, groupe_id=l3info.id),
        Matiere(nom="Bases de données", nb_seances=1, enseignant_id=profB.id, groupe_id=l3info.id),
        Matiere(nom="Réseaux", nb_seances=1, enseignant_id=profA.id, groupe_id=l3info.id),
        Matiere(nom="Marketing", nb_seances=2, enseignant_id=profC.id, groupe_id=l3gestion.id),
        Matiere(nom="Comptabilité", nb_seances=1, enseignant_id=profB.id, groupe_id=l3gestion.id),
    ])
    db.session.commit()

    print("Base peuplée avec des données de démonstration.")
