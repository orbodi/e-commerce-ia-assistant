from extensions import db

JOURS = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi"]
CRENEAUX = ["08h-10h", "10h-12h", "14h-16h", "16h-18h"]


class Enseignant(db.Model):
    __tablename__ = "enseignants"
    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(100), nullable=False)
    # disponibilites stockée en JSON : liste de [jour_idx, creneau_idx]
    disponibilites = db.Column(db.JSON, default=list)
    matieres = db.relationship("Matiere", backref="enseignant", cascade="all, delete-orphan")

    def disponibilites_set(self):
        return {tuple(d) for d in (self.disponibilites or [])}


class Salle(db.Model):
    __tablename__ = "salles"
    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(50), nullable=False)
    capacite = db.Column(db.Integer, nullable=False)
    type = db.Column(db.String(30), default="standard")


class Groupe(db.Model):
    __tablename__ = "groupes"
    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(50), nullable=False)
    effectif = db.Column(db.Integer, nullable=False)
    matieres = db.relationship("Matiere", backref="groupe", cascade="all, delete-orphan")


class Matiere(db.Model):
    __tablename__ = "matieres"
    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(100), nullable=False)
    nb_seances = db.Column(db.Integer, nullable=False, default=1)  # séances de 2h / semaine
    enseignant_id = db.Column(db.Integer, db.ForeignKey("enseignants.id"), nullable=False)
    groupe_id = db.Column(db.Integer, db.ForeignKey("groupes.id"), nullable=False)


class Creneau(db.Model):
    """Résultat généré par le solveur : une occurrence de séance placée."""
    __tablename__ = "creneaux"
    id = db.Column(db.Integer, primary_key=True)
    matiere_id = db.Column(db.Integer, db.ForeignKey("matieres.id"), nullable=False)
    salle_id = db.Column(db.Integer, db.ForeignKey("salles.id"), nullable=False)
    jour_index = db.Column(db.Integer, nullable=False)
    creneau_index = db.Column(db.Integer, nullable=False)

    matiere = db.relationship("Matiere")
    salle = db.relationship("Salle")

    @property
    def jour(self):
        return JOURS[self.jour_index]

    @property
    def horaire(self):
        return CRENEAUX[self.creneau_index]


class GenerationLog(db.Model):
    """Historique des générations, pour affichage sur le tableau de bord."""
    __tablename__ = "generation_log"
    id = db.Column(db.Integer, primary_key=True)
    date_generation = db.Column(db.DateTime, server_default=db.func.now())
    statut = db.Column(db.String(30))
    nb_seances_placees = db.Column(db.Integer)
    nb_heures_creuses = db.Column(db.Integer)
    duree_secondes = db.Column(db.Float)
