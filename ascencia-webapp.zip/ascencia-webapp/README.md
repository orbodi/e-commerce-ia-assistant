# Ascencia Scheduler — Prototype

Application web de génération automatique d'emplois du temps universitaires,
développée dans le cadre du mémoire de Licence :
« Conception et mise en œuvre d'un système intelligent pour la génération
et la publication automatique des emplois du temps universitaires basé sur
l'intelligence artificielle : cas d'Ascencia Keyce ».

## Installation

```bash
pip install -r requirements.txt
```

## Premier lancement (avec données de démonstration)

```bash
python3 seed.py      # crée la base ascencia.db et la peuple d'exemples
python3 app.py        # lance le serveur sur http://127.0.0.1:5000
```

Ouvrir ensuite http://127.0.0.1:5000 dans un navigateur.

## Utilisation sans données de démonstration (base vierge)

Si vous ne voulez pas des données d'exemple, ne lancez pas `seed.py` :
la base sera créée vide au premier lancement de `app.py`, et vous
pourrez saisir vos propres enseignants/salles/groupes/matières via
l'interface.

## Parcours dans l'application

1. **Enseignants** — saisir chaque enseignant et cocher ses créneaux
   de disponibilité sur la grille (5 jours × 4 créneaux de 2h).
2. **Salles** — saisir chaque salle avec sa capacité.
3. **Groupes** — saisir chaque groupe/filière avec son effectif.
4. **Matières** — associer chaque matière à un enseignant, un groupe,
   et un nombre de séances de 2h par semaine.
5. **Générer** — lancer le solveur (OR-Tools / CP-SAT). Le système
   place automatiquement toutes les séances en respectant les
   contraintes dures (pas de conflit enseignant/salle/groupe, capacité
   suffisante, disponibilités respectées) et en minimisant les heures
   creuses (contrainte souple).
6. **Emploi du temps** — consulter le résultat par groupe, par
   enseignant ou par salle, et l'exporter en Excel.

## Structure du projet

```
ascencia-webapp/
├── app.py            # routes Flask
├── models.py          # modèles SQLAlchemy (Enseignant, Salle, Groupe, Matiere, Creneau)
├── scheduler.py        # moteur OR-Tools (contraintes + résolution)
├── extensions.py       # instance SQLAlchemy
├── seed.py             # jeu de données de démonstration
├── requirements.txt
├── templates/           # pages HTML (Jinja2)
└── static/
    ├── css/style.css
    └── js/app.js
```

## Limites connues du prototype (à mentionner dans le mémoire)

- Créneaux fixes : 5 jours × 4 créneaux de 2h (paramétrable dans
  `models.py`, constantes `JOURS` et `CRENEAUX`).
- Édition des enseignants/salles/groupes/matières : pas de formulaire
  de modification (uniquement ajout/suppression) — à ajouter si le
  temps le permet.
- Authentification non implémentée (accès libre) — à ajouter avant
  tout déploiement réel dans l'établissement.
- Base SQLite : suffisante pour un prototype de démonstration ;
  migration vers PostgreSQL recommandée en cas de mise en production
  réelle (cf. partie « faisabilité technique » du mémoire).
