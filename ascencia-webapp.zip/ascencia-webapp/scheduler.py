"""
Moteur de génération automatique d'emploi du temps.

Modélisation CSP (Constraint Satisfaction Problem) résolue avec Google
OR-Tools (CP-SAT) :

CONTRAINTES DURES :
  - chaque séance est placée exactement une fois
  - une salle n'accueille qu'une séance par créneau
  - un enseignant ne donne qu'un cours par créneau
  - un groupe ne suit qu'un cours par créneau
  - la capacité de la salle doit être suffisante pour l'effectif du groupe
  - les disponibilités déclarées de l'enseignant sont respectées

CONTRAINTE SOUPLE (minimisée) :
  - les heures creuses (trous) dans l'emploi du temps de chaque groupe
"""

import time
from ortools.sat.python import cp_model
from models import db, Enseignant, Salle, Groupe, Matiere, Creneau, GenerationLog, JOURS, CRENEAUX

NB_CRENEAUX_JOUR = len(CRENEAUX)
SLOTS = [(j, c) for j in range(len(JOURS)) for c in range(NB_CRENEAUX_JOUR)]


class SolveResult:
    def __init__(self, status, nb_seances=0, nb_heures_creuses=0, duree=0.0, message=""):
        self.status = status
        self.nb_seances = nb_seances
        self.nb_heures_creuses = nb_heures_creuses
        self.duree = duree
        self.message = message


def generer_emploi_du_temps():
    debut = time.time()

    enseignants = Enseignant.query.all()
    salles = Salle.query.all()
    groupes = Groupe.query.all()
    matieres = Matiere.query.all()

    if not matieres:
        return SolveResult("VIDE", message="Aucune matière enregistrée : rien à planifier.")

    # --- Expansion en séances unitaires ---
    seances = []
    for m in matieres:
        for k in range(m.nb_seances):
            seances.append({"id": f"m{m.id}_s{k}", "matiere": m})

    def salles_compatibles(effectif):
        return [s for s in salles if s.capacite >= effectif]

    model = cp_model.CpModel()
    x = {}

    for s in seances:
        prof = s["matiere"].enseignant
        dispo = prof.disponibilites_set()
        groupe = s["matiere"].groupe
        for slot in SLOTS:
            if dispo and slot not in dispo:
                continue
            for salle in salles_compatibles(groupe.effectif):
                x[s["id"], slot, salle.id] = model.NewBoolVar(f'x_{s["id"]}_{slot}_{salle.id}')

    # Contrainte dure 1 : chaque séance placée une seule fois
    for s in seances:
        groupe = s["matiere"].groupe
        vars_s = [x[s["id"], slot, salle.id] for slot in SLOTS
                  for salle in salles_compatibles(groupe.effectif)
                  if (s["id"], slot, salle.id) in x]
        if not vars_s:
            return SolveResult("INFAISABLE",
                message=f"Impossible de placer « {s['matiere'].nom} » : aucune combinaison "
                        f"créneau/salle compatible (vérifier disponibilités et capacités).")
        model.Add(sum(vars_s) == 1)

    # Contrainte dure 2 : salle non partagée au même créneau
    for slot in SLOTS:
        for salle in salles:
            vars_slot = [x[s["id"], slot, salle.id] for s in seances
                         if (s["id"], slot, salle.id) in x]
            if vars_slot:
                model.Add(sum(vars_slot) <= 1)

    # Contrainte dure 3 : enseignant non partagé au même créneau
    for slot in SLOTS:
        for prof in enseignants:
            vars_slot = [x[s["id"], slot, salle.id] for s in seances
                         if s["matiere"].enseignant_id == prof.id
                         for salle in salles_compatibles(s["matiere"].groupe.effectif)
                         if (s["id"], slot, salle.id) in x]
            if vars_slot:
                model.Add(sum(vars_slot) <= 1)

    # Contrainte dure 4 : groupe non partagé au même créneau
    occ = {}
    for groupe in groupes:
        for j in range(len(JOURS)):
            for c in range(NB_CRENEAUX_JOUR):
                slot = (j, c)
                vars_slot = [x[s["id"], slot, salle.id] for s in seances
                             if s["matiere"].groupe_id == groupe.id
                             for salle in salles_compatibles(groupe.effectif)
                             if (s["id"], slot, salle.id) in x]
                v = model.NewBoolVar(f"occ_{groupe.id}_{j}_{c}")
                if vars_slot:
                    model.Add(sum(vars_slot) <= 1)
                    model.Add(v == sum(vars_slot))
                else:
                    model.Add(v == 0)
                occ[groupe.id, j, c] = v

    # Contrainte souple : minimiser les heures creuses par groupe
    penalites = []
    for groupe in groupes:
        for j in range(len(JOURS)):
            for c in range(NB_CRENEAUX_JOUR):
                avant = [occ[groupe.id, j, k] for k in range(c)]
                apres = [occ[groupe.id, j, k] for k in range(c + 1, NB_CRENEAUX_JOUR)]
                if not avant or not apres:
                    continue
                b_avant = model.NewBoolVar(f"av_{groupe.id}_{j}_{c}")
                b_apres = model.NewBoolVar(f"ap_{groupe.id}_{j}_{c}")
                model.AddMaxEquality(b_avant, avant)
                model.AddMaxEquality(b_apres, apres)
                gap = model.NewBoolVar(f"gap_{groupe.id}_{j}_{c}")
                model.Add(gap <= b_avant)
                model.Add(gap <= b_apres)
                model.Add(gap <= 1 - occ[groupe.id, j, c])
                model.Add(gap >= b_avant + b_apres - occ[groupe.id, j, c] - 1)
                penalites.append(gap)

    model.Minimize(sum(penalites)) if penalites else None

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 15
    solver.parameters.num_search_workers = 8
    status = solver.Solve(model)
    duree = time.time() - debut

    if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        GenerationLog.query.delete()
        log = GenerationLog(statut="ECHEC", nb_seances_placees=0, nb_heures_creuses=0, duree_secondes=duree)
        db.session.add(log)
        db.session.commit()
        return SolveResult("ECHEC", duree=duree,
            message="Aucune solution trouvée : les contraintes actuelles sont incompatibles "
                    "(trop de séances pour les créneaux/salles/disponibilités déclarés).")

    # --- Sauvegarde du résultat ---
    Creneau.query.delete()
    nb_placees = 0
    for s in seances:
        groupe = s["matiere"].groupe
        for slot in SLOTS:
            for salle in salles_compatibles(groupe.effectif):
                key = (s["id"], slot, salle.id)
                if key in x and solver.Value(x[key]):
                    db.session.add(Creneau(
                        matiere_id=s["matiere"].id, salle_id=salle.id,
                        jour_index=slot[0], creneau_index=slot[1],
                    ))
                    nb_placees += 1

    nb_creuses = int(solver.ObjectiveValue()) if penalites else 0
    log = GenerationLog(statut="OK", nb_seances_placees=nb_placees,
                         nb_heures_creuses=nb_creuses, duree_secondes=duree)
    db.session.add(log)
    db.session.commit()

    return SolveResult("OK", nb_seances=nb_placees, nb_heures_creuses=nb_creuses, duree=duree)
